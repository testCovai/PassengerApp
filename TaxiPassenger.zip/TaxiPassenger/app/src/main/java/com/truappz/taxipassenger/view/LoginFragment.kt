package com.truappz.taxipassenger.view

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.truappz.taxipassenger.databinding.FragmentLoginBinding
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.appcompat.view.ContextThemeWrapper
import com.truappz.taxipassenger.R


class LoginFragment : Fragment() {
    private var binding: FragmentLoginBinding? = null
    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        // create ContextThemeWrapper from the original Activity Context with the custom theme
        val contextThemeWrapper = ContextThemeWrapper(activity, R.style.AppTheme1)

        // clone the inflater using the ContextThemeWrapper
        val localInflater = inflater.cloneInContext(contextThemeWrapper)

        binding = FragmentLoginBinding.inflate(localInflater, container, false)
        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding?.tvHeading?.text = getString(R.string.txt_login)
        binding?.etMobileNumber?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(p0: Editable?) {
                if(p0.toString().length ==10){
                    binding?.btnNext?.alpha = 1.0f
                    binding?.btnNext?.isClickable = true
                }else{
                    binding?.btnNext?.alpha = 0.2f
                    binding?.btnNext?.isClickable = false
                }
            }

        })
        binding?.btnNext?.setOnClickListener {

        }
    }
}