package com.truappz.taxipassenger.view

class RegisterFragment {
}