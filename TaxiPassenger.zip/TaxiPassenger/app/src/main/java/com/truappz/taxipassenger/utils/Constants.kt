package com.truappz.taxipassenger.utils

const val BUNDLE_PARAM_PAGE = "page"