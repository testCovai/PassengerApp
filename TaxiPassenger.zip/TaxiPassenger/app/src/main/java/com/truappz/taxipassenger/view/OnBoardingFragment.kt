package com.truappz.taxipassenger.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.truappz.taxipassenger.utils.BUNDLE_PARAM_PAGE

class OnBoardingFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return layoutInflater.inflate(arguments!!.getInt(BUNDLE_PARAM_PAGE), container, false)
    }
}