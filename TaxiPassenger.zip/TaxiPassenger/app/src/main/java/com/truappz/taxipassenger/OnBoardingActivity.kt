package com.truappz.taxipassenger

import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.truappz.taxipassenger.adapter.OnBoardingPagerAdapter
import com.truappz.taxipassenger.utils.BUNDLE_PARAM_PAGE
import com.truappz.taxipassenger.view.OnBoardingFragment
import com.truappz.taxipassenger.view.ViewPagerListener
import kotlinx.android.synthetic.main.activity_on_boarding.*

class OnBoardingActivity : AppCompatActivity() {
    private lateinit var pagerAdapterView: OnBoardingPagerAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        setContentView(R.layout.activity_on_boarding)
        tvLogin.setOnClickListener {
            startActivity(Intent(this, SplashActivity::class.java))
            finish()
        }
        showOnBoarding()
    }

    private fun showOnBoarding() {
        pagerAdapterView = OnBoardingPagerAdapter(supportFragmentManager)
        addPagerFragments()
        vpTutorialScreen.adapter = pagerAdapterView
        vpTutorialScreen.addOnPageChangeListener(ViewPagerListener(this::onPageSelected))
    }

    private fun addPagerFragments() {
        pagerAdapterView.addFragments(OnBoardingFragment().apply {
            arguments = Bundle().apply { putInt(BUNDLE_PARAM_PAGE, R.layout.fragment_tutorial_screen1) }
        })
        pagerAdapterView.addFragments(OnBoardingFragment().apply {
            arguments = Bundle().apply { putInt(BUNDLE_PARAM_PAGE, R.layout.fragment_tutorial_screen2) }
        })
        pagerAdapterView.addFragments(OnBoardingFragment().apply {
            arguments = Bundle().apply { putInt(BUNDLE_PARAM_PAGE, R.layout.fragment_tutorial_screen3) }
        })
        pagerAdapterView.addFragments(OnBoardingFragment().apply {
            arguments = Bundle().apply { putInt(BUNDLE_PARAM_PAGE, R.layout.fragment_tutorial_screen4) }
        })
        pagerAdapterView.addFragments(OnBoardingFragment().apply {
            arguments = Bundle().apply { putInt(BUNDLE_PARAM_PAGE, R.layout.fragment_tutorial_screen5) }
        })
    }

    private fun onPageSelected(position: Int) {
        when (position) {
            0 -> {
                firstDotView.setBackgroundResource(R.drawable.current_position_shape)
                secondDotView.setBackgroundResource(R.drawable.disable_position_shape)
                thirdDotView.setBackgroundResource(R.drawable.disable_position_shape)
                fourthDotView.setBackgroundResource(R.drawable.disable_position_shape)
                fifthDotView.setBackgroundResource(R.drawable.disable_position_shape)
                tvLogin.visibility = View.INVISIBLE
            }
            1 -> {
                firstDotView.setBackgroundResource(R.drawable.disable_position_shape)
                secondDotView.setBackgroundResource(R.drawable.current_position_shape)
                thirdDotView.setBackgroundResource(R.drawable.disable_position_shape)
                fourthDotView.setBackgroundResource(R.drawable.disable_position_shape)
                fifthDotView.setBackgroundResource(R.drawable.disable_position_shape)
                tvLogin.visibility = View.INVISIBLE
            }
            2 -> {
                firstDotView.setBackgroundResource(R.drawable.disable_position_shape)
                secondDotView.setBackgroundResource(R.drawable.disable_position_shape)
                thirdDotView.setBackgroundResource(R.drawable.current_position_shape)
                fourthDotView.setBackgroundResource(R.drawable.disable_position_shape)
                fifthDotView.setBackgroundResource(R.drawable.disable_position_shape)
                tvLogin.visibility = View.INVISIBLE
            }
            3 -> {
                firstDotView.setBackgroundResource(R.drawable.disable_position_shape)
                secondDotView.setBackgroundResource(R.drawable.disable_position_shape)
                thirdDotView.setBackgroundResource(R.drawable.disable_position_shape)
                fourthDotView.setBackgroundResource(R.drawable.current_position_shape)
                fifthDotView.setBackgroundResource(R.drawable.disable_position_shape)
                tvLogin.visibility = View.INVISIBLE
            }
            4 -> {
                firstDotView.setBackgroundResource(R.drawable.disable_position_shape)
                secondDotView.setBackgroundResource(R.drawable.disable_position_shape)
                thirdDotView.setBackgroundResource(R.drawable.disable_position_shape)
                fourthDotView.setBackgroundResource(R.drawable.disable_position_shape)
                fifthDotView.setBackgroundResource(R.drawable.current_position_shape)
                tvLogin.visibility = View.VISIBLE
            }
        }
    }
}
