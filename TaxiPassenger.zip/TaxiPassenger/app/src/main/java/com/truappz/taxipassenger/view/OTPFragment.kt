package com.truappz.taxipassenger.view

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.appcompat.view.ContextThemeWrapper
import com.truappz.taxipassenger.R
import com.truappz.taxipassenger.databinding.FragmentOtpBinding
import kotlinx.android.synthetic.main.custom_toolbar.*


class OTPFragment : Fragment() {
    private var binding: FragmentOtpBinding? = null
    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        // create ContextThemeWrapper from the original Activity Context with the custom theme
        val contextThemeWrapper = ContextThemeWrapper(activity, R.style.AppTheme1)

        // clone the inflater using the ContextThemeWrapper
        val localInflater = inflater.cloneInContext(contextThemeWrapper)

        binding = FragmentOtpBinding.inflate(localInflater, container, false)
        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        tvHeading?.text = getString(R.string.txt_verify_otp)
        tvSkip.visibility = View.GONE
        binding?.etOTP?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(p0: Editable?) {
                if(p0.toString().length ==10){
                    binding?.btnLogin?.alpha = 1.0f
                    binding?.btnLogin?.isClickable = true
                }else{
                    binding?.btnLogin?.alpha = 0.2f
                    binding?.btnLogin?.isClickable = false
                }
            }

        })
        binding?.btnLogin?.setOnClickListener {

        }
    }
}